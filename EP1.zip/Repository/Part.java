package Repository;
import java.util.Map;
import java.util.HashMap;

public class Part{
	private String description;
	private String Repository;
	private Map<Part, Integer> subParts;
	private int id;
	
	//Constructor
	public Part(int id, String repo, String description) {
		this.id = id;
		this.Repository = repo;
		this.description = description;
		subParts = new HashMap<Part, Integer>();
	}
	
	//Method for adding sub parts
	public void addSubPart(Part subPart) {
		int quant = 0;
		if(subParts.get(subPart) != null) {quant = subParts.get(subPart);}
		subParts.put(subPart, quant+1);
	}
	
	//Method for printing all sub parts of current part
	public void listSubParts() {
		System.out.println("SubParts of " + description + ":");
		System.out.print("	"); //Sub parts are printed with spaces for readability
		for(Map.Entry<Part ,Integer> partEntry : subParts.entrySet()) {
			Part part = partEntry.getKey();
			int quant = partEntry.getValue();
			
			System.out.print(part.description);
			
			if(part.subParts.size() > 0) 
			{System.out.println(" (composta)");}
			else 
			{System.out.println(" (primitiva)");}
			System.out.print("	");
			System.out.println("quantity: " + quant);
		}
	}
	
	//Method for printing parts
	public void print() {
		System.out.println("repository:  " + Repository);
		System.out.println("id:          " + id);
		System.out.println("description: " + description);
	}
	
	//Equals method used for the hash map
	public boolean equals(Object obj) {
		return this == obj;
	}
}