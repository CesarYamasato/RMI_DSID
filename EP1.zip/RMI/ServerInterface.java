package RMI;
import java.rmi.*;
import Repository.*;

public interface ServerInterface extends Remote{
	public void lisp(); //Listar as peças que estão no repositório
	public Part getp(int id); //Obter uma peça com um determinado id
	public boolean addp(String description); //Adciona uma peça ao repositório rmeoto
	
	//Os demais métodos exigidos são implementados pela classe client
}