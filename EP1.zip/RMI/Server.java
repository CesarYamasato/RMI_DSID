package RMI;
import Repository.*;

import java.net.MalformedURLException;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

class Server extends  UnicastRemoteObject implements ServerInterface{
	
	public static PartRepository Repository;

	protected Server(String name) throws RemoteException {
		super();
		Repository = new PartRepository(name);
	}

	@Override
	public void lisp() {
		// TODO Auto-generated method stub
		Repository.listParts();
	}

	@Override
	public Part getp(int id) {
		// TODO Auto-generated method stub
		return Repository.getPart(id);
	}

	@Override
	public boolean addp(String description) {
		// TODO Auto-generated method stub
		return Repository.addPart(description);
	}
	
	static public void main(String[] args) throws RemoteException, MalformedURLException {
		Server RepoServer = new Server(args[0]);
		Naming.rebind(args[0], RepoServer);
	}
	
}