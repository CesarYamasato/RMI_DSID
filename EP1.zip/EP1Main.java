import Repository.*;

class Main{
	public static void main(String[] args) {
		PartRepository Repo = new PartRepository("teste");
		Repo.addPart("Computador");
		Repo.addPart("Loja");
		Repo.addPart("Cachorro");
		Repo.addPart("Cebola");
		
		Repo.listParts();
		
		Part parte = Repo.getPart(0);
		Part subParte = Repo.getPart(2);
		
		parte.addSubPart(subParte);
		parte.addSubPart(subParte);
		parte.listSubParts();
		
		Repo.removePart(1);
		
		Repo.listParts();
		
		Repo.addPart("pulga");
		
		System.out.println("AQUI");
		
		Repo.listParts();
	}
}